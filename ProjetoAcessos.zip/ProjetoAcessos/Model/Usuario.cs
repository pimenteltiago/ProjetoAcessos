﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAcessos {
    class Usuario {
        
        //atributos
        private int id;
        private string nome;
        private List<Ambiente> ambientes;

        //Construtor
        public Usuario() {
            this.id = 0;
            this.nome = "";
            this.ambientes = new List<Ambiente>();
        }

        //Metodos
        public bool concederPermissao(Ambiente ambiente) {
            foreach (Ambiente ambPesquisado in this.ambientes) {
                if (ambPesquisado.Id == ambiente.Id) {
                    return false;
                }
            }
            this.ambientes.Add(ambiente);
            return true;
        }

        public bool revogarPermissao(Ambiente ambiente) {
            try {
                this.ambientes.RemoveAt(ambiente.Id);
            } catch (Exception e) {
                return false;
            }
            return true;
        }

        //Getters e Setters
        public int Id { get => id; set => id = value; }
        public string Nome { get => nome; set => nome = value; }
        internal List<Ambiente> Ambientes { get => ambientes; set => ambientes = value; }
    }
}
