﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAcessos {
    class Log {

        //Atributos
        private DateTime dtAcesso;
        private Usuario usuario;
        private bool tipoAcesso;

        //Construtor
        public Log(Usuario usr, bool tipoAcesso) {
            this.dtAcesso = DateTime.Now;
            this.usuario = usr;
            this.tipoAcesso = tipoAcesso;
        }

        //Getters e Setters

        public DateTime DtAcesso { get => dtAcesso; set => dtAcesso = value; }
        public bool TipoAcesso { get => tipoAcesso; set => tipoAcesso = value; }
        internal Usuario Usuario { get => usuario; set => usuario = value; }


    }
}
