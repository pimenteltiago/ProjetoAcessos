﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAcessos {
    class Ambiente {

        //atributos
        private int id;
        private string nome;
        private Queue<Log> logs;
        
        //Construtor
        public Ambiente() {
            this.id = 0;
            this.nome = "";
            this.logs = new Queue<Log>();
        }

        //Metodos
        public void registrarLog(Log log) {
            this.logs.Enqueue(log);
        }

        //Getters e Setters
        public int Id { get => id; set => id = value; }
        public string Nome { get => nome; set => nome = value; }
        internal Queue<Log> Logs { get => logs; set => logs = value; }
    }
}
