﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAcessos {
    class Cadastro {

        //Atributos
        private List<Usuario> usuarios;
        private List<Ambiente> ambientes;

        //Construtor
        public Cadastro() {
            this.usuarios = new List<Usuario>();
            this.ambientes = new List<Ambiente>();
        }

        //Metodos
        public void adicionarUsuario(Usuario usuario) {
            usuario.Id = this.usuarios.Count;
            this.usuarios.Add(usuario);
        }
        public bool removerUsuario(Usuario usuario) {
            try {
                usuarios.RemoveAt(usuario.Id);
            } catch (Exception) {
                return false;
            }
            return true;
        }
        public Usuario pesquisarUsuario(Usuario usuario) {
            foreach (Usuario userPesquisado in usuarios) {
                if (userPesquisado.Id == usuario.Id) {
                    return userPesquisado;
                }
            }
            return null;
        }

        public void adicionarAmbiente(Ambiente ambiente) {
            ambiente.Id = this.ambientes.Count;
            this.ambientes.Add(ambiente);
        }

        public bool removerAmbiente(Ambiente ambiente) {
            try {
                this.ambientes.RemoveAt(ambiente.Id);
            } catch (Exception) {
                return false;
            }
            return true;
        }

        public Ambiente pesquisarAmbiente(Ambiente ambiente) {
            foreach (Ambiente ambPesquisado in ambientes) {
                if (ambPesquisado.Id == ambiente.Id) {
                    return ambPesquisado;
                }
            }
            return null;
        }

        //Custom
        public void registrarLog(Usuario usr, Ambiente amb) {
            bool resultAcesso = false;
            usr = this.pesquisarUsuario(usr);
            amb = this.pesquisarAmbiente(amb);
            //usr.Ambientes[amb.Id] = amb;

            foreach (Ambiente ambPesq in usr.Ambientes) {
                if (ambPesq.Id == amb.Id) {
                    resultAcesso = true;
                }
            }
            usr.Ambientes[amb.Id].registrarLog(new Log(usr, resultAcesso));
        }

        public void upload() {

        }
        public void download() {
        
        }

    }
}
