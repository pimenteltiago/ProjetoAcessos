﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAcessos {
    class Program {
        static void Main(string[] args) {
            View vw = new View();
            vw.Menu();
        }
    }
}
