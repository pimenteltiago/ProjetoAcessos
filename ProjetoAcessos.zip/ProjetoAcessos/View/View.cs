﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ProjetoAcessos {
    class View {

        //Atributos
        public Cadastro cd;

        //Construtor
        public View() {
            Console.Write("" +
                "-------------------------------\n" +
                "        Projeto Acessos" +
                "\n-------------------------------"
            );
            cd = new Cadastro();
            cd.download();
            Thread.Sleep(1250);
        }
        
        //Metodos
        public void Menu() {
            Console.Clear();
            Console.Write("" +
                " -------------------------------------------\n" +
                "              Menu Principal\n" +
                " -------------------------------------------\n" +
                " 0.  Sair\n" +
                " 1.  Cadastrar ambiente\n" +
                " 2.  Consultar ambiente\n" +
                " 3.  Excluir ambiente\n" +
                " 4.  Cadastrar usuario\n" +
                " 5.  Consultar usuario\n" +
                " 6.  Excluir usuario\n" +
                " 7.  Conceder permissao de acesso ao usuario\n" +
                " 8.  Revogar permissao de acesso ao usuario\n" +
                " 9.  Registrar acesso\n" +
                " 10. Consultar logs de acesso\n" +
                " \n" +
                " Escolha: "
            );
            Int16 opcao = -1;
            try {
                while (opcao < 0 || opcao > 10) {
                    opcao = Convert.ToInt16(Console.ReadLine());
                }
            } catch (Exception) {
                Console.WriteLine(" Opcao Invalida");
            }
            switch (opcao) {
                case 1:
                    Ambiente newAmbiente = new Ambiente();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "      Cadastrar ambiente" +
                        "\n-------------------------------\n" +
                        " Digite o nome do novo ambiente: "
                    );
                    try {
                        newAmbiente.Nome = Console.ReadLine();
                        cd.adicionarAmbiente(newAmbiente);
                    } catch (Exception e) {
                        Console.WriteLine("Erro: "+e);
                    }
                    Console.WriteLine(" Adicionado.");
                    Thread.Sleep(1250);
                    break;
                case 2:
                    Ambiente ambPesquisado = new Ambiente();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "      Consultar ambiente" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do a ambiente: "
                    );
                    try {
                        ambPesquisado.Id = Convert.ToInt32(Console.ReadLine());
                        ambPesquisado = cd.pesquisarAmbiente(ambPesquisado);
                    } catch (Exception e) {
                        Console.WriteLine(" Erro: " + e);
                    }
                    Console.Write(" Encontrado: "+ambPesquisado.Nome);
                    Thread.Sleep(1750);
                    break;
                case 3:
                    Ambiente ambExcluido = new Ambiente();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "      Excluir ambiente" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do ambiente: "
                    );
                    try {
                        ambExcluido.Id = Convert.ToInt32(Console.ReadLine());
                        if (cd.removerAmbiente(ambExcluido)) {
                            Console.WriteLine(" Removido.");
                        } 
                    } catch (Exception e) {
                        Console.WriteLine(" Erro: " + e);
                    }
                    Thread.Sleep(1250);
                    break;

                //Usuario

                case 4:
                    Usuario newUser = new Usuario();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "      Cadastrar usuario" +
                        "\n-------------------------------\n" +
                        " Digite o nome do novo usuario: "
                    );
                
                    try {
                        newUser.Nome = Console.ReadLine();
                        cd.adicionarUsuario(newUser);
                    } catch (Exception e) {
                        Console.WriteLine("Erro: " + e);
                    }
                    Console.WriteLine(" Adicionado.");
                    Thread.Sleep(1250);
                    break;
                case 5:
                    Usuario userPesq = new Usuario();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "      consultar usuario" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do usuario: "
                    );
                    try {
                        userPesq.Id = Convert.ToInt32(Console.ReadLine());
                        userPesq = cd.pesquisarUsuario(userPesq);
                    } catch (Exception e) {
                        Console.WriteLine(" Erro: " + e);
                    }
                    Console.Write(" Encontrado: " + userPesq.Nome);
                    Thread.Sleep(1750);
                    break;
                case 6:
                    Usuario userExcluido = new Usuario();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "       Excluir usuario" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do usuario: "
                    );
                    try {
                        userExcluido.Id = Convert.ToInt32(Console.ReadLine());
                        if (cd.removerUsuario(userExcluido)) {
                            Console.WriteLine(" Removido.");
                        }
                    } catch (Exception e) {
                        Console.WriteLine(" Erro: " + e);
                    }
                    Console.WriteLine(" Usuario Revogado.");
                    Thread.Sleep(1250);
                    break;

                //Pemissoes
                case 7:
                    Ambiente ambPermissao = new Ambiente();
                    Usuario usrPermissao = new Usuario();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "      Conceder permissao" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do usuario: "
                    );
                    try {
                        usrPermissao.Id = Convert.ToInt32(Console.ReadLine());
                        Console.Write(" Digite o identificador do ambiente: ");
                        ambPermissao.Id = Convert.ToInt32(Console.ReadLine());

                        usrPermissao = cd.pesquisarUsuario(usrPermissao);
                        usrPermissao.concederPermissao(ambPermissao);
                    } catch (Exception e) {
                        Console.WriteLine(" Erro: "+e);
                        Thread.Sleep(5000);
                    }
                    Console.WriteLine(" Permissao Concedida.");
                    Thread.Sleep(1250);
                    break;
                case 8:
                    Ambiente ambRevogar = new Ambiente();
                    Usuario usrRevogar = new Usuario();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "         Revogar permissao" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do usuario: "
                    );
                    try {
                        usrRevogar.Id = Convert.ToInt32(Console.ReadLine());
                        Console.Write(" Digite o identificador do ambiente: ");
                        ambRevogar.Id = Convert.ToInt32(Console.ReadLine());

                        usrPermissao = cd.pesquisarUsuario(usrRevogar);
                        usrPermissao.revogarPermissao(ambRevogar);
                    } catch (Exception e) {
                        Console.WriteLine(" Erro: " + e);
                        Thread.Sleep(5000);
                    }
                    Console.WriteLine(" Permissao Revogada.");
                    Thread.Sleep(1250);
                    break;
                case 9:
                    Usuario usrAcesso = new Usuario();
                    Ambiente ambAcesso = new Ambiente();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "         Registrar acesso" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do usuario: "
                    );
                    try {
                        usrAcesso.Id = Convert.ToInt32(Console.ReadLine());
                        Console.Write(" Digite o identificador do ambiente: ");
                        ambAcesso.Id = Convert.ToInt32(Console.ReadLine());
                        cd.registrarLog(usrAcesso, ambAcesso);
                    } catch (Exception e) {
                        Console.WriteLine(" Erro: " + e);
                        Thread.Sleep(5000);
                    }
                    Console.WriteLine(" Registrado.");
                    Thread.Sleep(1250);
                break;
                case 10:
                    Ambiente ambConsulta = new Ambiente();
                    Console.Write("" +
                        "-------------------------------\n" +
                        "          Consultar log" +
                        "\n-------------------------------\n" +
                        " Digite o identificador do ambiente: "
                    );
                    ambConsulta.Id = Convert.ToInt32(Console.ReadLine());
                    ambConsulta = cd.pesquisarAmbiente(ambConsulta);
                    foreach (Log l in ambConsulta.Logs)
                    Console.Write(l.ToString() + "\n");
                    break;
                default:
                    cd.upload();
                    System.Environment.Exit(0);
                    break;
            }
            Menu();
        }
    }
}
