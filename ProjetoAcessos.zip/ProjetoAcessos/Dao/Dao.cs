﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace ProjetoAcessos.Dao {
    class Dao {

        //Atributos

        //Construtor
        public Dao() {
            
        }

        //Metodos
        public void salvarConteudo() {
        
        }

        public void carregarConteudo() {
        
        }
    }
}
